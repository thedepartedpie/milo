﻿namespace Milo.Model
{
    public class MyMenuItem
    {

        public string Title { get; set; }
        public string Icon { get; set; }
        public string PageName { get; set; }
    }
}
