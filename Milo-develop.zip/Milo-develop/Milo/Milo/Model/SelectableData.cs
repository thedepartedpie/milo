﻿using System;
namespace Milo.Model
{
    public class SelectableData
    {
        public int id { get; set; }
        public string name { get; set; }
        public string email_id { get; set; }
        public bool Selected { get; set; }
    }
}
