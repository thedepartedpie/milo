﻿namespace Milo.Model
{
    public class StringResponse
    {
        public int status { get; set; }
        public string msg { get; set; }
        public string token_code { get; set; }
        public string data { get; set; }
    }
}
