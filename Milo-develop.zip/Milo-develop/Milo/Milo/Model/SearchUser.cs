﻿using System.Collections.Generic;

namespace Milo.Model
{
    public class SearchUser
    {
        public int status { get; set; }
        public List<SelectableData> data { get; set; }
    }
}
