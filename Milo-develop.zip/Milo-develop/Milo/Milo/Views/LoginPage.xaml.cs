﻿
namespace Milo.Views
{
    public partial class LoginPage
    {
        public LoginPage()
        {
            InitializeComponent();
        }
    }
}
