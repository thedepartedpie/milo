﻿namespace Milo.Views
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
